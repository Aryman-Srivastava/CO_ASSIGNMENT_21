tok_length = {
    "add": 4, "sub": 4, "mov": 3, "ld": 3, "st": 3,
    "mul": 4, "div": 4, "rs": 3, "ls": 3, "xor": 4,
    "or": 4, "and": 4, "not": 3, "cmp": 3, "jmp": 2,
    "jlt": 2, "jgt": 2, "je": 2, "hlt": 1
}